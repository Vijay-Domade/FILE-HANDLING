package March28.org;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadOperationApp 
{

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		int choice;
		Scanner xyz=new Scanner(System.in);
		
		System.out.println("1:read all file data");
		System.out.println("2:read numbers of lines in file");
		System.out.println("3:read number of words in file");
		System.out.println("4:read number of character in file");
		System.out.println("5:separate integer data if present in file ");
		System.out.println("6:reverse every word of file and store in another file");
		System.out.println("7:reverse complete file and store in another file");
		System.out.println("Enter your choice");
		choice=xyz.nextInt();
		switch(choice)
		{
		case 1:
			FileReader fr=new FileReader("F:\\DemoJava\\data.txt");
			int data;
			while((data=fr.read())!=-1)
			{
				System.out.print((char)data);
				
			}
			break;
		case 2:
			FileReader f=new FileReader("F:\\DemoJava\\data.txt");
			BufferedReader br=new BufferedReader(f);//reader
			String d;
			while((d=br.readLine())!=null)
			{
				System.out.println(d);
				Thread.sleep(1000);
			}
			break;
		case 3:
			FileReader f2=new FileReader("F:\\DemoJava\\data.txt");
			BufferedReader br2=new BufferedReader(f2);//reader
			String w;
			String[]word;
			while((w=br2.readLine())!=null)
			{
				 word=w.split(" ");
				for(int i=0;i<word.length;i++)
				{
					System.out.println(word[i]);
					Thread.sleep(1000);
				}
			}
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		default:
			System.out.println("Wrong choice");
			break;
			
		
		}
	}

}
