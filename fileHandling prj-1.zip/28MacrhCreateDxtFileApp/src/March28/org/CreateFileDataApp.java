package March28.org;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CreateFileDataApp 
{

	public static void main(String[] args) throws IOException
	{
		File f=new File("F:\\DemoJava\\data.txt");
		FileWriter fw=new FileWriter(f,true);//create file with append mode.
		BufferedWriter bw=new BufferedWriter(fw);
		Scanner xyz=new Scanner(System.in);
		System.out.println("Enter data in file");
		String data;
		String str;
		do
		{
		data=xyz.nextLine();
		bw.write(data);//write data using BufferedWriter
		bw.newLine();
		System.out.println("Continue--->Yes/No");
		str=xyz.nextLine();
		System.out.println(str);
		}
		while(str.compareTo("Yes")==0);
		bw.close();
		fw.close();
		System.out.println("Success......");
	}
	
}

